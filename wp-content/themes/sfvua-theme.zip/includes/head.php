		<!-- remove before launch ============================================ -->
		<meta name="robots" content="noindex">
		<!-- /remove before launch ============================================ -->


		<!-- Stylesheets -->
		<link href="bootstrap.min.css" rel="stylesheet">
		<link href="revolution-slider.css" rel="stylesheet">
		<link href="style.css" rel="stylesheet">
		<!-- Responsive -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		<link href="bootstrap-margin-padding.css" rel="stylesheet">
		<link href="responsive.css" rel="stylesheet">
		<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
		<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->

		<script src="https://use.fontawesome.com/1d5d687778.js"></script>